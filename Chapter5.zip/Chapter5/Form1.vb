﻿Option Strict On
Public Class Form1
    Dim dblTotal As Double
    Dim dblFemaleTotal As Double
    Dim dblMaleTotal As Double
    Dim intFemale As Integer
    Dim intMale As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For dblGPA As Double = 1.0 To 4.0 Step 0.1
            listGPA.Items.Add(dblGPA.ToString("F1"))
        Next dblGPA
        listGPA.SelectedIndex = 20 ' 3.0 GPA default
        dblTotal = 0.0
        dblFemaleTotal = 0.0
        dblMaleTotal = 0.0
        intFemale = 0
        intMale = 0

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim dblG As Double
        Dim dblAvg As Double
        Double.TryParse(listGPA.SelectedItem.ToString, dblG)
        If radFemale.Checked Then
            intFemale += 1
            dblFemaleTotal += dblG
        Else
            intMale += 1
            dblMaleTotal += dblG
        End If
        dblTotal += dblG
        ' Calculate and write averages to the labels
        dblAvg = dblTotal / (intFemale + intMale)
        lblAll.Text = dblAvg.ToString("F2")
        If intFemale > 0 Then
            dblAvg = dblFemaleTotal / intFemale
            lblFemale.Text = dblAvg.ToString("F2")
        End If
        If intMale > 0 Then
            dblAvg = dblMaleTotal / intMale
            lblMale.Text = dblAvg.ToString("F2")
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
